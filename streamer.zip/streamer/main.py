
import time
import json
import psycopg2
import redis

# --------------------------------------
# إعدادات الاتصال
# --------------------------------------
# إذا تشغله داخل Docker، استخدم أسماء الحاويات
PG_HOST = "postgres"
PG_DB = "streaming_db"
PG_USER = "admin"
PG_PASSWORD = "admin"

REDIS_HOST = "redis"
REDIS_PORT = 6379
REDIS_DB = 0
REDIS_LIST = "latest_events"
REDIS_LIST_MAX_LEN = 100  # الاحتفاظ بآخر 100 حدث فقط

# --------------------------------------
# اتصال PostgreSQL
# --------------------------------------
pg_conn = psycopg2.connect(
    host=PG_HOST,
    dbname=PG_DB,
    user=PG_USER,
    password=PG_PASSWORD
)

# --------------------------------------
# اتصال Redis
# --------------------------------------
r = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=REDIS_DB, decode_responses=True)

last_id = 0  # آخر حدث تمت معالجته

print("Streamer started: PostgreSQL → Redis")

while True:
    try:
        with pg_conn.cursor() as cur:
            cur.execute("""
                SELECT id, content_id, user_id, event_type, event_ts, device
                FROM engagement_events
                WHERE id > %s
                ORDER BY id ASC
                LIMIT 10
            """, (last_id,))
            
            rows = cur.fetchall()

            for row in rows:
                event = {
                    "event_id": row[0],
                    "content_id": str(row[1]) if row[1] else None,
                    "user_id": str(row[2]) if row[2] else None,
                    "type": row[3].upper() if row[3] else None,  # تحويل النوع إلى uppercase
                    "timestamp": row[4].isoformat() if row[4] else None,
                    "device": row[5],
                    "processed_at": time.time(),
                    "source": "postgres"  # إضافة مصدر الحدث
                }

                # إرسال الحدث إلى Redis
                r.lpush(REDIS_LIST, json.dumps(event))
                r.ltrim(REDIS_LIST, 0, REDIS_LIST_MAX_LEN - 1)  # الاحتفاظ بآخر 100 حدث فقط

                print(f"Streamed event ID {event['event_id']} → Redis")

                last_id = row[0]  # تحديث آخر حدث

        time.sleep(5)  # تأخير بين كل دورة

    except Exception as e:
        print("Error:", e)
        time.sleep(5)
